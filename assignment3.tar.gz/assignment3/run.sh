#!/bin/bash

javac *.java
appletviewer gasket.html
appletviewer ellipse.html