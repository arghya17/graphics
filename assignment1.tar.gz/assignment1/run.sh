#!/bin/bash

javac *.java
appletviewer test.html
appletviewer grid.html
