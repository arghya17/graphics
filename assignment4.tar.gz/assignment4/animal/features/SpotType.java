package animal.features;

public enum SpotType {
    SPOTTED,SPOTLESS
};
