package animal.features;
public enum HairType {
    HAIRLESS,HAIRY;
}
