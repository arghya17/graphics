package animal.features;
public enum Size {
    BIG,SMALL,LONG,MEDIUM,SHORT;
}
