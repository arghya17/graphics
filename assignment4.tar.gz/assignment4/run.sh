#!/bin/bash

javac *.java
appletviewer mouse.html