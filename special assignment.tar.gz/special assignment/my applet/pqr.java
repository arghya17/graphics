
import java.awt.*;
import xyz.abc.color;;

public class pqr extends color {
    public void paint(Graphics g) {
        fill(g);
    }
}
