#!/bin/bash

javac *.java
appletviewer test.html
appletviewer rect.html
appletviewer pqr.html
