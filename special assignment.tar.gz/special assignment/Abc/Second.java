package Abc;

public class Second {
    public void fun() {
        System.out.println("This is fun method of Second class in Abc package");
    }

    public static void main(String args[]) {
        System.out.println("Second class of abc");
    }
}
