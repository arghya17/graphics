package Abc.xyz;

public class third {
    public void f() {
        System.out.println("This is f function of third class in package Abc.xyz");
    }
}
