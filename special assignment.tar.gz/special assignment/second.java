
public class second {
    public void fun() {
        System.out.println("This is fun function of second object");
    }

    public static void main(String args[]) {
        System.out.println("This is second class");
    }

}
